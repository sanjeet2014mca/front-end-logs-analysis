
/**
 *  Application level existance, maintain session 
 */
export class UserSession {

    private id: number;
    private userName: string;
    private fName: string;
    private mName: string;
    private lName: string;
    private mobileNo: string;
    private emailId: string;
    private fullName: string ;

	constructor(){

	}

    // constructor( private userId: number, private dbId: Object, private usrName: string, private firstName: string,
	// 	private middleName: string, private lastName: string, private mobile: string, 
	// 	private email: string, private completeName: string ) {
	// 	this.id = userId;
	// 	this.datataBaseId = dbId;
	// 	this.userName = usrName;
	// 	this.fName = firstName;
	// 	this.mName = middleName;
	// 	this.lName = lastName;
	// 	this.mobileNo = mobile;
	// 	this.emailId = email;
	// 	this.fullName = completeName;
	// }

	/**
	 * @return the id
	 */
	public getId() {
		return this.id;
	}

	/**
	 * @param id the id to set
	 */
	public setId(id) {
		this.id = id;
	}

    /**
	 * @return the UserName
	 */
	public  getUserName() {
		return this.userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public setUserName(userName) {
		this.userName = userName;
	}

	/**
	 * @return the fName
	 */
	public getFName() {
		return this.fName;
	}

	/**
	 * @param fName the fName to set
	 */
	public setFName(fName) {
		this.fName = fName;
	}

	/**
	 * @return the mName
	 */
	public getMName() {
		return this.mName;
	}

	/**
	 * @param mName the mName to set
	 */
	public setMName(mName) {
		this.mName = mName;
	}

	/**
	 * @return the lName
	 */
	public getLName() {
		return this.lName;
	}

	/**
	 * @param lName the lName to set
	 */
	public setLName(lName) {
		this.lName = lName;
	}

	/**
	 * @return the mobileNo
	 */
	public getMobileNo() {
		return this.mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public setMobileNo(mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the email
	 */
	public getEmail() {
		return this.emailId;
	}

	/**
	 * @param email the email to set
	 */
	public setEmail(email) {
		this.emailId = email;
	}

	/**
	 * @return the fullName
	 */
	public getFullName() {
		return this.fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public setFullName(fullName) {
		this.fullName = fullName;
	}

}