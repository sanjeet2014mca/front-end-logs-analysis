

import { RegisterUser } from '../../model/bo/registerUser';
/**
 * Application level under session and request level existance
 * 
 */
export class User {

  userName: string = null;
  password: string = null;
  userDetailsRequest: RegisterUser;
  constructor() {
     this.userDetailsRequest = new RegisterUser();
  }
}