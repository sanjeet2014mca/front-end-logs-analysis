/**
 * If user wants to send any feedback or he wants to communicate, then
 * 
 */
export class ForgotAccess{

    emailId: string;  
  
}