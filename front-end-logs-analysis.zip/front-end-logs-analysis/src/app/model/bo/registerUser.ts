

export class RegisterUser{

  id: bigint = null;
  fName: string = null;
  mName: string = null;
  lName: string = null;
  mobile: string = null;
  email: string = null;
  gender: any = null;
  dob: string = null;
  password: string = null;
  passwordConfirm: string = null;
}