
export class UserDetails{
  
  private id:Number = 0;
  private datataBaseId: Object;
  private userName :string = null;
  private fName: string = null;
  private mName: string = null;
  private lName: string = null;
  private mobileNo: string = null;
  private email: string = null;
  private password:string = null;
  private confirmPassword:string = null;
  private fullName: string ;

   /**
	 * @return the datataBaseId
	 */
	public  getDatataBaseId() {
		return this.datataBaseId;
	}

	/**
	 * @param datataBaseId the datataBaseId to set
	 */
	public setDatataBaseId(datataBaseId) {
		this.datataBaseId = datataBaseId;
	}

	/**
	 * @return the id
	 */
	public getId() {
		return this.id;
	}

	/**
	 * @param id the id to set
	 */
	public setId(id) {
		this.id = id;
	}

	/**
	 * @return the UserName
	 */
	public  getUserName() {
		return this.userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public setUserName(userName) {
		this.userName = userName;
	}

	/**
	 * @return the fName
	 */
	public getFName() {
		return this.fName;
	}

	/**
	 * @param fName the fName to set
	 */
	public setFName(fName) {
		this.fName = fName;
	}

	/**
	 * @return the mName
	 */
	public getMName() {
		return this.mName;
	}

	/**
	 * @param mName the mName to set
	 */
	public setMName(mName) {
		this.mName = mName;
	}

	/**
	 * @return the lName
	 */
	public getLName() {
		return this.lName;
	}

	/**
	 * @param lName the lName to set
	 */
	public setLName(lName) {
		this.lName = lName;
	}

	/**
	 * @return the mobileNo
	 */
	public getMobileNo() {
		return this.mobileNo;
	}

	/**
	 * @param mobileNo the mobileNo to set
	 */
	public setMobileNo(mobileNo) {
		this.mobileNo = mobileNo;
	}

	/**
	 * @return the email
	 */
	public getEmail() {
		return this.email;
	}

	/**
	 * @param email the email to set
	 */
	public setEmail(emailId) {
		this.email = emailId;
	}
    
    /**
	 * @return the email
	 */
	public getPassword() {
		return this.password;
	}

	/**
	 * @param email the email to set
	 */
	public setPassword(password) {
		this.password = password;
	}

    /**
	 * @return the email
	 */
	public getConfirmPassword() {
		return this.confirmPassword;
	}

	/**
	 * @param email the email to set
	 */
	public setConfirmPassword(confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	/**
	 * @return the fullName
	 */
	public getFullName() {
		return this.fullName;
	}

	/**
	 * @param fullName the fullName to set
	 */
	public setFullName(fullName) {
		this.fullName = fullName;
	}
}