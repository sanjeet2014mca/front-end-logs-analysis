
// export class Message{
//     type: string;
//     message:string;
// }

export class Message{

    type: string;
    text: string;
    autoClose: boolean;
    keepAfterRouteChange: boolean;
    fade: boolean;

    constructor(init?:Partial<Message>) {
        Object.assign(this, init);
    }
}

export enum MessageType {
    Success,
    Error,
    Info,
    Warning
}
