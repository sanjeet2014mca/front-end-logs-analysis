
export class UserDataFetchParams{
  
  private id:Number;
  private datataBaseId: Object;

   /**
	 * @return the datataBaseId
	 */
	public  getDatataBaseId() {
		return this.datataBaseId;
	}

	/**
	 * @param datataBaseId the datataBaseId to set
	 */
	public setDatataBaseId(datataBaseId) {
		this.datataBaseId = datataBaseId;
	}

	/**
	 * @return the id
	 */
	public getId() {
		return this.id;
	}

	/**
	 * @param id the id to set
	 */
	public setId(id) {
		this.id = id;
	}

}