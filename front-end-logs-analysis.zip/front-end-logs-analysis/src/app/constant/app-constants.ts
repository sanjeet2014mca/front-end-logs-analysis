
export const emailPattern: string = '^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$';
export const mobilePattern: string = '^[0-9][0-9]{9}$';

export const formErrors: { [key: string]: string } = {
    required: 'This is a required field',
    pattern: 'Email must be a valid email address (leia@alderaan.net).',
    minLength: 'Password must contain at least 6 characters.',
    mobileLength: 'Mobile number should be 10 digit long',
    mobile_Pattern: 'Mobile number should be numeric',
    mismatch: 'Passwords don\'t match.',
    unique: 'Passwords must contain at least 3 unique characters.'
};

export const loginInvalid = "The username and password were not recognised";

export const SESSION_EXPIRED = 'Expired';

export const SESSION_EXPIRED_STATUS = 500;