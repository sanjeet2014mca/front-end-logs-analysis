    import { HttpClient, HttpHeaders } from '@angular/common/http'; 

    /*
    * httpOptions 
    */
    export const httpOptions = {
        headers: new HttpHeaders(
            { 
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        )
    };

    export const headers = new HttpHeaders()
        .set('Access-Control-Allow-Origin','*')
        .set('Content-Type', 'application/json');

    /*
    * Context root, main url's
    */

    export const apiRoot: string = 'http://localhost:8080/nxp-app/v1';
    export const SESSION_VALIDATE: string = 'http://localhost:8080/SessionManagementSystem/session_management/session_validate';

    /*
    * login related uri's
    */
    export const  LOGIN_USER:string = apiRoot+'/login'; 
    export const  LOGOUT_USER:string = apiRoot+'/logout'; 

    /*
    * User registration related uri's
    */    
    export const  REGISTER_USER:string = apiRoot+'/register';

    /*
    * File related uri's
    */    
    export const  UPLOAD:string = apiRoot+'/upload';
    export const  DOWNLOAD:string = apiRoot+'/download';
    export const  GET_FILES:string = apiRoot+'/getFiles';

    /*
    * logs related uri's
    */
    export const  PIPELINES:string = apiRoot+'/getPipeLines';
    export const  LOGS:string = apiRoot+'/logs';
    export const  DOWNLOAD_LOGS:string = LOGS+'/downloads';

    /*
    * ContactUs related uri's
    */
    export const contactUs: string = apiRoot+'/contactus';

    export const  CONTACT_US_SAVE:string = '/save';
    export const  CONTACT_US_DELETE:string = '/delete';
    export const  CONTACT_US_FETCH_ALL:string = '/fetch_all';
    export const  CONTACT_US_FETCH:string = '/fetch';

        
    /*
    * User modification related uri's
    */
    export const user:string = apiRoot+'/user';

    export const  MODIFY_USER:string = '/update'; 
    export const  MODIFY_USER_CREDENTIALS:string = '/update_pwd'; 
    export const  FETCH_USER:string = '/fetch'; 
