import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { User } from '../model/bo/user';
import * as Urls from '../constant/urls';
@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private user: User;
  private httpClient: HttpClient;
  private headers = Urls.httpOptions;

  constructor(private https: HttpClient) {
    this.httpClient = https;
  }

  private setParams(parameters): HttpParams {
    let params = new HttpParams();
    const keys = Object.keys(parameters);

    keys.forEach( (key) => {
        params = params.append(key, parameters[key].toString());
    });

    return params;
}

  validateLogin(usr): Observable<User> {

    //const httpParams = new HttpParams().append('userRequest', usr.Json);
    //const httpHeader = new HttpHeaders().append('Content-Type', 'application/json');

    console.log("Login url: " + usr);
    const api = Urls.LOGIN_USER;
    return this.httpClient.post<User>(api, usr, this.headers);
  }

  logout() {
    const api = Urls.LOGOUT_USER;
    return this.httpClient.delete(api, this.headers);
  }

}
