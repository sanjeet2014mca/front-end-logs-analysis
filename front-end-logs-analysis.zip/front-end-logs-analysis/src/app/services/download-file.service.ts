import { HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest, HttpResponse, HttpParams, HttpEvent, HttpEventType } from '@angular/common/http';
import { Injectable, Output } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { BehaviorSubject,  Subscription } from 'rxjs';

import * as Urls from '../constant/urls';
import { MessageService } from '../services/message.service';
import { GenericService } from '../services/generic.service';
import {Message} from '../model/servicemessage/message';

@Injectable({
  providedIn: 'root'
})
export class DownloadFileService {

  private httpClient: HttpClient;

  private messageService: MessageService;
  private genericService: GenericService;
  private message: Message;

  constructor(private client: HttpClient) { 
    this.httpClient = client;
  }

  // Fetches the names of files to be displayed in the downloads list.
  fetchFileNames() {
    Urls.GET_FILES
    return this.httpClient
      .get<string[]>(Urls.GET_FILES);
  }

  downloadFile(fileName:string){
    //window.location.href = 'http://localhost:8080/downloadFile/' + fileName;
    return this.httpClient.get<string>(Urls.DOWNLOAD+'/'+fileName, Urls.httpOptions);
  }
}
