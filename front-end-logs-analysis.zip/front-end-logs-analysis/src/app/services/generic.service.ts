import { Injectable, ErrorHandler } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { Router } from '@angular/router';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';

import { MessageService } from '../services/message.service';
import { UserSession } from '../model/sessionManager/user-session';
import * as appConstants from '../constant/app-constants';

@Injectable({
  providedIn: 'root'
})
export class GenericService implements ErrorHandler {

  private messageService: MessageService;
  private isPageFound: Boolean;
  @SessionStorage('userSession') userSession: UserSession;

  headersDisplay: string;
  dropDownId:number;

  constructor(private router: Router, private msgService: MessageService, private location: Location,
  public sessionService: SessionStorageService, ) {
  this.messageService = msgService;
  }

   navigate(uri: string) {
    this.router.navigate(['/'+uri]);
    //  this.router.navigateByUrl('/' + uri);
    //window.location.reload();
  }

  goBack() {
    this.location.back();
  }

  public setHeadersDisplay(str: string){
    this.headersDisplay = str;
  }

  public getHeadersDisplay(){
    return this.headersDisplay;
  }

  public setDropDownId(id:number){
    this.dropDownId = id;
  }
  public getDropDownId(){
    return this.dropDownId;
  }
  
  /**
   * Handle any errors from the API
   */

  public handleError(err) {
      let errorMessage: string;
      const error = err.error;

      if (error && error.errorMessage) {
        errorMessage = error.errorMessage;
      }else {
        errorMessage = 'Server-side error occured.'; 
      }
      console.log(err);

      const JsonParseError = appConstants.SESSION_EXPIRED;
      // let matches = error.message.match(new RegExp(JsonParseError, 'g'));
      const matches = new RegExp(JsonParseError, 'ig');
      const res = matches.test(errorMessage);
      if (error && error.status === appConstants.SESSION_EXPIRED_STATUS && res === true) {
        // if(this.userSession == null){
          if (JSON.stringify(window.location.pathname) !== '/login') {
            this.sessionService.set('userSession', null);
            this.userSession = null;

            this.router.navigate( ['/login'] );
            this.messageService.error('UserSession expired, please log in ');
          }
        // }else{
        //   this.router.navigate( [JSON.stringify(window.location.pathname)] );
        // }
      }

      return errorMessage;
  }

  public isEmptyObject(obj: Object) {
    return this.isValid(obj);
  }

  public isEmptyString(obj: string) {
    return this.isValid(obj);
  }

  public isNullOrEmptyList(objList: Array<Object>) {
    return this.isValid(objList);
  }

  private isValid(obj) {

    if (typeof obj === undefined) { return true; }
    if (typeof obj === null) { return true; }
    if (obj == null) { return true; }

    if (obj instanceof  String) {
      if (obj == null) { return true; }
    }
    if (obj instanceof  Number) {
      if (obj === 0) { return true; }
    }
    if (obj instanceof  Array) {
      if (obj.length === 0) { return true; }
    }
    if (obj && (Object.keys(obj).length === 0) ) { return true; }

  }

  public ifPageFound() {
    return this.isPageFound;
  }

  public setIsPageFound(ifPageFound: Boolean) {
    this.isPageFound = ifPageFound;
  }

 /** Log a Service message with the MessageService */
 public success(message: string) {
   this.messageService.success(message);
 }

 public error(message: string) {
   this.messageService.error(message);
 }

 public clearMessage() {
   this.messageService.clearMessage();
 }

}

