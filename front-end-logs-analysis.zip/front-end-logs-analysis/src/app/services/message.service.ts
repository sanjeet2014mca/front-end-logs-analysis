import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';

import { Message, MessageType } from '../model/servicemessage/message';


@Injectable({
  providedIn: 'root'
})
export class MessageService {

  private subject = new Subject<any>();

  private keepAfterNavigationChange = false;
  private selectorShowOrhide = false;
  constructor(private router: Router, private location: Location) {
     // clear alert message on route change
      router.events.subscribe(event => {
          if (event instanceof NavigationStart) {
            if (this.keepAfterNavigationChange) {
                // only keep for a single route change
                this.keepAfterNavigationChange = false;
            } else {
                // clear alert message
                this.clearMessage();
            }
          }
      });
  }

  success(message: string, keepAfterNavigationChange = false) {
      this.keepAfterNavigationChange = keepAfterNavigationChange;
      this.commonMessage('success', message);
  }

  info(message: string, keepAfterNavigationChange = false) {
      this.keepAfterNavigationChange = keepAfterNavigationChange;
      this.commonMessage('info', message);
  }

  error(message: string, keepAfterNavigationChange = false) {
      this.keepAfterNavigationChange = keepAfterNavigationChange;
      this.commonMessage('error', message);
  }

  commonMessage(msgType: string, message: string) {
      this.selectorShowOrhide = true;
      this.clearMessage();
      this.subject.next({ type: msgType, text: message });
      this.autoHide();
  }

  autoHide() {
      setTimeout(() => {
           this.clearMessage();
      }, 6000);
  }

  clearMessage() {
   this.subject.next('');
   this.selectorShowOrhide = false;
  }

  unsubscribe() {
      this.subject.unsubscribe();
  }

  getMessage(): Observable<any> {
      return this.subject.asObservable();
  }

}
