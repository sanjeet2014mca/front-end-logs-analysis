import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

import * as Urls from '../constant/urls';
import { MessageService } from '../services/message.service';
import { GenericService } from '../services/generic.service';
import {Message} from '../model/servicemessage/message';

@Injectable({
  providedIn: 'root'
})
export class LogsServiceService {

  private http: HttpClient;
  private messageService: MessageService;
  private message: Message;

  constructor(private https: HttpClient, private router: Router,
    public genericService: GenericService) {

    this.http = https;
   }

   fetchLogsData(id: number){
    return this.http.get(Urls.LOGS+'/'+id, Urls.httpOptions);
   }

   collectPipeLines(){
    return this.http.get(Urls.PIPELINES, Urls.httpOptions);6
   }

   downloadLogs(id: number){
    const link = document.createElement('a');
    link.setAttribute('target', '_blank');
    link.setAttribute('href', Urls.DOWNLOAD_LOGS+'/'+id+'/'+this.genericService.getHeadersDisplay());
    document.body.appendChild(link);
    link.click();
    link.remove();
   }

   downloadModalLogs(id){
     console.log(Urls.DOWNLOAD_LOGS+'/'+id.value+'/'+this.genericService.getHeadersDisplay());
    return this.http.get(Urls.DOWNLOAD_LOGS+'/'+id.value+'/'+this.genericService.getHeadersDisplay(), Urls.httpOptions);
   }


}
