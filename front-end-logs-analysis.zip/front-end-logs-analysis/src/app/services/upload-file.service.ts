import { HttpClient, HttpErrorResponse, HttpHeaders, HttpRequest, HttpResponse, HttpParams, HttpEvent, HttpEventType } from '@angular/common/http';
import { Injectable, Output } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { BehaviorSubject,  Subscription } from 'rxjs';

import * as Urls from '../constant/urls';
import { MessageService } from '../services/message.service';
import { GenericService } from '../services/generic.service';
import {Message} from '../model/servicemessage/message';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  private httpClient: HttpClient;

  private messageService: MessageService;
  private genericService: GenericService;
  private message: Message;

  constructor(private client: HttpClient) { 
    this.httpClient = client;
  }
  
  uploadFile(file: File): Observable<HttpEvent<{}>> {

    var formData: any = new FormData();
    formData.append("file", file);

    return this.httpClient.post<any>(Urls.UPLOAD, formData, {
      reportProgress: true,
      observe: 'events'
    }).pipe(
      catchError(this.handleError)
    )
  }

  private getEventMessage(event: HttpEvent<any>, formData) {

    switch (event.type) {
      case HttpEventType.UploadProgress:
        return this.fileUploadProgress(event);
		break;
      case HttpEventType.Response:
        return event.body;
		break;
      default:
        return event.type;
    }
  }

  private fileUploadProgress(event) {
    const percentDone = Math.round(100 * event.loaded / event.total);
    return { status: 'progress', message: percentDone };
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      
      //console.error('An error occurred:', error.error.message);
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      //console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    console.log(errorMessage);
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }

}