import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';

import { UserSession } from '../model/sessionManager/user-session';
import * as Urls from '../constant/urls';

import { UserDetails } from '../model/bo/userDetails';
import { UserDataFetchParams } from '../model/fetch_params/user_data_fetch_params';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private httpClient: HttpClient;
  private url: string = Urls.user;
  private headers = Urls.httpOptions;
  @SessionStorage('userSession') userSession;

  constructor(private https: HttpClient) {
    this.httpClient = https;
  }

  updateRecord(userDetails: UserDetails) {
    console.log(userDetails);
    const api = this.url + Urls.MODIFY_USER;
    return this.httpClient.put<UserDetails>(api, userDetails, this.headers);
  }

  fetchRecord(userDataFetchParams: UserDataFetchParams) {
    const api = Urls.FETCH_USER ; // Urls.SESSION_VALIDATE

    const body = {
      'object': userDataFetchParams,
      'userSession': this.userSession,
      'uri': Urls.FETCH_USER,
      'url': this.url
    };

    const params = new HttpParams()
      .set('object', JSON.stringify(userDataFetchParams))
      .set('userSession', this.userSession)
      .set('uri', this.url + Urls.FETCH_USER);

    const header = this.headers;

    const options = {
      header,
      params,
      withCredentials: true
    };

    return this.httpClient.post<UserDataFetchParams>(api, body, this.headers);
    // return this.httpClient.post<UserDataFetchParams>(api, userDataFetchParams, this.headers);
    // return this.httpClient.get<UserDetails>(api, this.headers);
  }

  updateCredentials(userDetails: UserDetails) {
    console.log(userDetails);
    const api = this.url + Urls.MODIFY_USER_CREDENTIALS;
    return this.httpClient.put<UserDetails>(api, userDetails, this.headers);
  }


}
