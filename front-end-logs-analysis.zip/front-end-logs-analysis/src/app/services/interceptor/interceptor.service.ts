import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpResponse, HttpParams, HttpHeaders } from '@angular/common/http';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { NgxSpinnerService } from "ngx-spinner";

import { UserSession } from '../../model/sessionManager/user-session';
import { GenericService } from '../../services/generic.service';
import { MessageService } from '../../services/message.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService implements HttpInterceptor{

  @SessionStorage('userSession') userSession: UserSession;

  httpParams = new HttpParams().append('userRequest', null);
  httpHeader = new HttpHeaders().append('Content-Type', 'application/json');

  constructor(public sessionService: SessionStorageService, private router: Router,
    public messageService: MessageService, public genericService: GenericService, private spinner: NgxSpinnerService) {}

    intercept(request: HttpRequest<any>, next: HttpHandler ): Observable<HttpEvent<any>> {

      this.spinner.show();
 
      // setTimeout(() => {
      //   /** spinner ends after 5 seconds */
      //   this.spinner.hide();
      // }, 5000);
      
      const pathname = window.location.pathname;
      const sessionObject: UserSession = this.sessionService.get('userSession');

      if (this.userSession == null) {
  
        if (pathname === '/register' || pathname === '/login') {
          return next.handle(request);
        } else {
          this.router.navigate( ['/login'] );
          console.log( ' UserSession expired, please log in ' );
          //this.messageService.error('UserSession expired, please log in ');
          //this.toastr.info('UserSession expired, please log in ');
        }
  
      } else {
        this.router.navigate( [pathname] );
      }
      return next.handle(request);
    }
  }
  
