import { Injectable } from '@angular/core';
import { UserSession } from '../model/sessionManager/user-session';

@Injectable({
  providedIn: 'root'
})
export class SessionService {
  userSession: UserSession;

  constructor() { }

  storeDataInSession(session: UserSession) {
    this.userSession =  session;
    console.log('Data stored in user session service ');
    console.log( this.userSession);
  }

}
