import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot } from '@angular/router';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';

import { UserSession } from '../model/sessionManager/user-session';

@Injectable()
export class RouteguardService implements CanActivate {

  @SessionStorage('userSession') userSession;
  constructor(public sessionService: SessionStorageService, public router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
    console.log(' ' + route);
    const sessionObject: UserSession = this.userSession; // this.sessionService.get("userSession"); //
    if (sessionObject != null) {
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }
}
