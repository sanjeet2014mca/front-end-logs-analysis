import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { Router } from '@angular/router';

import { RegisterUser } from '../model/bo/registerUser';
import * as Urls from '../constant/urls';
import { MessageService } from '../services/message.service';
import { GenericService } from '../services/generic.service';
import {Message} from '../model/servicemessage/message';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private http: HttpClient;
  private messageService: MessageService;
  private genericService: GenericService;
  private message: Message;

  constructor(private https: HttpClient, private router: Router) {

    this.http = https;
   }

   registerRecord(registerUser: RegisterUser) {
     return this.http.post(Urls.REGISTER_USER, registerUser, Urls.httpOptions);
   }

}
