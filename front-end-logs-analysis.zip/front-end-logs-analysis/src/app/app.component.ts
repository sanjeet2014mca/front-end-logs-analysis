import { Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

import { LoginComponent } from './components/login-register/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HeaderComponent } from './components/header/header.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[LoginComponent, DashboardComponent, HeaderComponent]
})
export class AppComponent {
  
  title = 'NXP-App';

  constructor(private headerComponent : HeaderComponent, private dashboardComponent : DashboardComponent,
    private toastr: ToastrService) { 
      console.log("App Component executed!.");
 }

 ngOnInit(): void {
  
 }
}
