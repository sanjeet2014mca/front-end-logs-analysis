import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AngularWebStorageModule } from 'angular-web-storage';
import { NgxSpinnerModule } from "ngx-spinner";

import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './module/material/material.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login-register/login/login.component';
import { RegisterComponent } from './components/login-register/register/register.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ForgotAccessComponent } from './components/login-register/forgot-access/forgot-access.component';
import { MessagesComponent } from './components/messages/messages.component';
import { HeaderComponent } from './components/header/header.component';
import { DownloadComponent } from './components/download/download.component';
import { UploadComponent } from './components/upload/upload.component';
import { LogsRecordsComponent } from './components/logs-records/logs-records.component';
import { LogsRecordsConfirmModalComponent } from './components/modal/logs-records-confirm-modal/logs-records-confirm-modal.component';
import { LogsRecordsMainModalComponent } from './components/modal/logs-records-main-modal/logs-records-main-modal.component';

import { RouteguardService } from './services/routeguard.service';
import { RegisterService } from './services/register.service';
import { LoginService } from './services/login.service';
import { SessionService } from './services/session.service';
import { InterceptorService } from './services/interceptor/interceptor.service';
import { UserService } from './services/user.service';
import { MessageService } from './services/message.service';
import { GenericService } from './services/generic.service';
import { LogsServiceService } from './services/logs-service.service';

import { UserSession } from './model/sessionManager/user-session';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomepageComponent,
    DashboardComponent,
    PageNotFoundComponent,
    ForgotAccessComponent,
    MessagesComponent,
    HeaderComponent,
    DownloadComponent,
    UploadComponent,
    LogsRecordsComponent,
    LogsRecordsConfirmModalComponent,
    LogsRecordsMainModalComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule ,
    HttpClientModule,
    AngularWebStorageModule,
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot({
      timeOut: 5000,
      closeButton: true,
      tapToDismiss: true,
      preventDuplicates: true,
      positionClass: 'toast-bottom-left',
      progressBar: true,
    }), // ToastrModule added
    NgxSpinnerModule,
    AppRoutingModule,
    MaterialModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
    {  provide: GenericService, useClass: GenericService, },
    RouteguardService, LoginService, SessionService, MessageService,
    RegisterService, UserSession, UserService, LogsServiceService
  ], bootstrap: [AppComponent]
})
export class AppModule { 
  constructor() {
    console.log('AppModule here');
  }
}
