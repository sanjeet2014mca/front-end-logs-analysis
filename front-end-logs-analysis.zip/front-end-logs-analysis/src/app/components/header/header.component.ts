import { Component, OnInit, ChangeDetectorRef  } from '@angular/core';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { UserSession } from '../../model/sessionManager/user-session';

import { MessageService } from '../../services/message.service';
import { LoginService } from '../../services/login.service';
import { GenericService } from '../../services/generic.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  ifSessionExists: Boolean =  false;
  @SessionStorage('userSession') userSession;
  ifPageFound: any;

  constructor(public sessionService: SessionStorageService, public router: Router, public loginService: LoginService,
    public genericService: GenericService, public messageService: MessageService, private spinner: NgxSpinnerService) {
      
      // if(this.userSession == null){
      //    console.log("Session not found, redirecting to login page!.")
      //    this.router.navigate(['/login']);
      // }
      
      const path = window.location.pathname.split('/');
      if (path.length === 2) {
        const ifValidUri = this.filterURI(path[1]);
        if (ifValidUri) {
          this.genericService.setIsPageFound(true);
        } else {
          this.genericService.setIsPageFound(false);
        }
        console.log( ' Now, Page found  ? -> ' + this.genericService.ifPageFound());
      }
      this.ifPageFound = this.genericService.ifPageFound();
  }

  ngOnInit() {
    const pathname = window.location.pathname;
    if (this.userSession == null) {
      this.messageService.error('Please login here');
      return;
    }
   }

  logout() {

    this.sessionService.set('userSession', null);
    this.userSession = null;

    this.loginService.logout().subscribe( (res: any) => {
        this.router.navigate(['/login']);
        this.messageService.success(res['message']);
      }, (err) => {
        this.messageService.error(this.genericService.handleError(err.error));
      }
    );
    this.spinner.hide();
  }

  public isPageFound() {
     return this.isPageFound;
   }

   public setIsPageFound(isPageFound: Boolean) {
     this.ifPageFound = isPageFound;
   }

   filterURI(uri: String) {
    let ifValidUri = false;
    const arr = this.router.config;
    for (let i = 0; i < arr.length; i++) {
      const validPath = arr[i]['path'];
      if (uri === validPath) {
        ifValidUri = true;
        break;
      }
    }
    return ifValidUri;
  }

}
