import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { HttpClient, HttpResponse, HttpRequest, HttpEvent,
         HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { catchError, last, map, tap } from 'rxjs/operators';
import { Observable, Subscription, of } from 'rxjs';
import { UploadFileService } from '../../services/upload-file.service';
import { FormBuilder, FormGroup } from "@angular/forms";
import {MatSnackBar} from '@angular/material/snack-bar';

export class FileDetails {
  name: string;
  progress: number;
}

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.css']
  // ,animations: [
  //   trigger('fadeInOut', [
  //         state('in', style({ opacity: 100 })),
  //         transition('* => void', [
  //               animate(300, style({ opacity: 0 }))
  //         ])
  //   ])
  // ]
})
export class UploadComponent implements OnInit {

  form: FormGroup;
  progress: number = 0;
  
  loaded = 0;
  selectedFiles: FileList;
  uploadedFiles: FileDetails[] = [];
  showProgress = false;

  // @ViewChild("fileInput", {static: false}) fileInput: ElementRef;
  // files  = []; 

  constructor(public uploader: UploadFileService, private snackBar: MatSnackBar) { }

  ngOnInit() {
  }
  
  
  
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  uploadFiles() {
    this.showProgress = true;
    this.uploadedFiles = [];
    Array.from(this.selectedFiles).forEach(file => {
      const fileDetails = new FileDetails();
      fileDetails.name = file.name;
      this.uploadedFiles.push(fileDetails);
      //this.uploader.uploadFile(file)
      this.uploader.uploadFile(file).subscribe((event: HttpEvent<any>) => {
          if (event.type === HttpEventType.UploadProgress) {
            this.loaded = Math.round(100 * event.loaded / event.total);
            fileDetails.progress = this.loaded;
          }
        })
      //   .subscribe(event => {
      //   if (event instanceof HttpResponse) {
      //     if (this.selectedFiles.item(this.selectedFiles.length - 1) === file) {
      //       // Invokes fetchFileNames() when last file in the list is uploaded.
      //       this.fileService.fetchFileNames();
      //     }
      //   }
      // });
    });
  }

  reset(){
    this.selectedFiles = undefined;
    this.showProgress = false;
    this.uploadedFiles = [];
  }









//   onClick() {  
//     const fileInput = this.fileInput.nativeElement;
//     fileInput .onchange = () => {  
//         for (let index = 0; index < fileInput .files.length; index++){  
//              const file = fileInput .files[index];  
//              this.files.push({ data: file, inProgress: false, progress: 0});  
//         }  
//           this.upload();  
//     };  
//     fileInput.click();  
//  }

//   private upload() {  
//     this.fileInput.nativeElement.value = '';  
//     this.files.forEach(file => { 
//      this.uploadFile(file.data);
//     });  
//   }


//   uploadFile(file) {
//     this.uploader.uploadFile(file).subscribe((event: HttpEvent<any>) => {
//       switch (event.type) {
//         case HttpEventType.Sent:
//           console.log('Request has been made!');
//           break;
//         case HttpEventType.ResponseHeader:
//           console.log('Response header has been received!');
//           break;
//         case HttpEventType.UploadProgress:
//           this.updateProgress(event, file);
//           break;
//         case HttpEventType.Response:
//           console.log('File successfully uploaded!', event.body);
//       }
//     })
//     console.log("done!.");
//   }
  
//   updateProgress(event, file){
//     this.progress = Math.round(event.loaded / event.total * 100);
//     for (let i = 0; i < this.files.length; i++) {
//       if(this.files[i].data.name == file.name){
//         this.files[i].progress = this.progress;
//       }
//     }
//     console.log(`Uploaded! ${this.progress}%`);
//   }



}
