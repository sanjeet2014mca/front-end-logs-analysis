import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forgot-access',
  templateUrl: './forgot-access.component.html',
  styleUrls: ['./forgot-access.component.css']
})
export class ForgotAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
