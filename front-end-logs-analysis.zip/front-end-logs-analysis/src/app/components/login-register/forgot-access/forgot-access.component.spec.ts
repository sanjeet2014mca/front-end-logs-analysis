import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ForgotAccessComponent } from './forgot-access.component';

describe('ForgotAccessComponent', () => {
  let component: ForgotAccessComponent;
  let fixture: ComponentFixture<ForgotAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
