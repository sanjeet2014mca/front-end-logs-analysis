import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, ViewChild  } from '@angular/core'; // OnInit
import { NgForm, FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from "ngx-spinner";

import { LoginService } from '../../../services/login.service';
import { SessionService } from '../../../services/session.service';
import { GenericService } from '../../../services/generic.service';
import { MessageService } from '../../../services/message.service';

import { User } from '../../../model/bo/user';
import { RegisterUser } from '../../../model/bo/registerUser';
import { UserSession } from '../../../model/sessionManager/user-session';
import * as constant from '../../../constant/app-constants';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User();
  @SessionStorage('userSession') userSession;
  message: string;

  loginInvalid: Boolean = false;

  ifSignIn: Boolean = true;
  ifSignUp: Boolean = false;
  fullName: string = null;

  formErrors = constant.formErrors;
  emailPattern = constant.emailPattern;

  constructor(public sessionService: SessionService, public sessionStorageService: SessionStorageService,
      public loginService: LoginService, public messageService: MessageService,
      public genericService: GenericService, public toastr: ToastrService, public router: Router, 
      private spinner: NgxSpinnerService) {
    this.user =  new User();
    this.ifSignUp = false;
    this.loginInvalid = true;
    this.genericService.setIsPageFound(true);
  }

  ngOnInit(): void {
    console.log('Login initialize');
  }

  login(user: User, loginForm: NgForm) {
   
    if (loginForm.invalid) {
      this.messageService.error('Please submit correct and mandatory data');
      return false;
    }
    this.loginService.validateLogin(user).subscribe( (res: any) => {
        setTimeout(function() {
            this.spinner.hide();
            if (res) {
              const session = this.sessionCreator(res);
              this.sessionService.storeDataInSession(session);
            }
            this.genericService.navigate('logs');
        }.bind(this), 1000);

        }, (err) => {
          this.spinner.hide();
          this.messageService.error(this.genericService.handleError(err));
        }
    );
  }

  sessionCreator(userDetailsResponse) {

    const session: UserSession = new UserSession();
    session.setId(userDetailsResponse.id);
    session.setFName(userDetailsResponse.fName);
    session.setLName(userDetailsResponse.lName);
    session.setEmail(userDetailsResponse.email);
    session.setMobileNo(userDetailsResponse.mobileNo);
    this.fullName = userDetailsResponse.fName + " " + userDetailsResponse.lName;
    session.setFullName(this.fullName);
    this.userSession = session;
    return session;
  }

  resetForm(form: NgForm) {
    form.reset();
    console.log('Reseting form for again submitting it.');
    this.messageService.clearMessage();
  }

  enableSignUp(form: NgForm) {
    console.log('Enabling sign up -> ' + status);
    this.ifSignUp = true;
    this.ifSignIn = false;
    this.resetForm(form);
  }

}
