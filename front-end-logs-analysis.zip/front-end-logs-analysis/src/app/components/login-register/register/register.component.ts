import { Component, OnInit, Input } from '@angular/core';
import { NgForm, FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";

import { RegisterUser } from '../../../model/bo/registerUser';
import { RegisterService } from '../../../services/register.service';
import { GenericService } from '../../../services/generic.service';
import { MessageService } from '../../../services/message.service';

import * as constant from '../../../constant/app-constants';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerUser: RegisterUser = new RegisterUser();
  registerService: RegisterService;
  private genericService: GenericService;
  formErrors = constant.formErrors;

  emailPattern = constant.emailPattern;
  mobilePattern = constant.mobilePattern;
  genders = [{ "name": "Male", id: "Male"},{ "name": "Female", id: "Female"},{ "name": "Others", id: "Others"}];
  
  constructor(private service: RegisterService, private router: Router, private gnService: GenericService,
    private messageService: MessageService, private spinner: NgxSpinnerService) {
    this.registerService = service;
    this.genericService = gnService;
  }

  ngOnInit(): void {
  }
 
  onRegisterUser(data: RegisterUser, form: NgForm) {
    
    this.registerService.registerRecord(data).subscribe(res => {
        setTimeout(function() {
            this.resetForm(form);
            this.messageService.success(res['message']);
        }.bind(this), 1000);
        }, (err) => {
           this.messageService.error(this.genericService.handleError(err.error));
        }, () => { this.spinner.hide(); }
    );
  }

  resetForm(form: NgForm) {
    form.reset();
    this.messageService.clearMessage();
  }

}


