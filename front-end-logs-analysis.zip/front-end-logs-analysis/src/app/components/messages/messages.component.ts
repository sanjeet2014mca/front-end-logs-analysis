import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';

import { MessageService } from '../../services/message.service';
import { Message, MessageType } from '../../model/servicemessage/message';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.css']
})
export class MessagesComponent implements OnInit, OnDestroy {

  @Input() id = 'default-alert';
  @Input() fade = true;

  private subscription: Subscription;
  message: Message;

  constructor(public messageService: MessageService) {
    this.subscription = this.messageService.getMessage().subscribe(message => { this.message = message; });
  }

  ngOnInit() {

  }

  ngOnDestroy() {
   this.messageService.unsubscribe();
  }

  clearMessage() {
    this.messageService.clearMessage();
  }

}
