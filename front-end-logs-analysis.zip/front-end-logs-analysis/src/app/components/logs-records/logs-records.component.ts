import {Component} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
import { MatDialog } from '@angular/material/dialog';

import { LogsRecordsConfirmModalComponent } from '../../components/modal/logs-records-confirm-modal/logs-records-confirm-modal.component';

import { LogsServiceService } from '../../services/logs-service.service';
import { GenericService } from '../../services/generic.service';
import { MessageService } from '../../services/message.service';
import { AnimationQueryMetadata } from '@angular/animations';

@Component({
  selector: 'app-logs-records',
  templateUrl: './logs-records.component.html',
  styleUrls: ['./logs-records.component.css']
})
export class LogsRecordsComponent {
  
  logs:any = [];
  options:any;
  id: number;
  displayedHeaders: Array<{id: string}> = [];
  headers: Array<{id: string}> = [];
  tableData:any;
  pipeLinesDatas:any;

  constructor(public  logsService: LogsServiceService, public messageService: MessageService,
    public genericService: GenericService, private spinner: NgxSpinnerService, public router: Router,
    public dialog: MatDialog) {
      this.collectPipeLines();
  }

  optionsControl = new FormControl('', Validators.required);

  collectPipeLines(){
    this.logsService.collectPipeLines().subscribe(data =>{
      this.options = data;
    }, (err) => {
      this.messageService.error(this.genericService.handleError(err));
    });
    this.spinner.hide();
  }

  fetchLogsDetails(optinsId){
    if(optinsId.value != undefined){
      this.genericService.setDropDownId(optinsId);
      const data = this.logsService.fetchLogsData(optinsId.value).subscribe(data =>{
        this.prepareTableData(data["pipeLines"]);
      }, (err) => {
        this.messageService.error(this.genericService.handleError(err));
      });
    }else{
    }
    this.spinner.hide();
  }

  prepareTableData(pipeLines){
    this.headers = [];
    for (var pipeLinesData of pipeLines["pipeLinesDatas"]) {
      this.headers.push({ id: pipeLinesData["headersDisplay"] });
    }
    this.id = pipeLines["id"];
    this.tableData = pipeLines["pipeLinesDatas"];
  }

  downloadLogs(id:number, headersDisplay:string){
    this.genericService.setHeadersDisplay(headersDisplay);
    this.logsService.downloadLogs(id);
  }

  openDialog(headersDisplay: string): void {
    this.genericService.setHeadersDisplay(headersDisplay);
    const dialogRef = this.dialog.open(LogsRecordsConfirmModalComponent, {
      width: '250px',
      data: { name: headersDisplay }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
    });
  }
}