import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogsRecordsComponent } from './logs-records.component';

describe('LogsRecordsComponent', () => {
  let component: LogsRecordsComponent;
  let fixture: ComponentFixture<LogsRecordsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogsRecordsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogsRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
