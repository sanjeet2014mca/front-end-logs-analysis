import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogsRecordsConfirmModalComponent } from './logs-records-confirm-modal.component';

describe('LogsRecordsConfirmModalComponent', () => {
  let component: LogsRecordsConfirmModalComponent;
  let fixture: ComponentFixture<LogsRecordsConfirmModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogsRecordsConfirmModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogsRecordsConfirmModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
