import { Component, Input, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';

import { LogsRecordsMainModalComponent } from '../../../components/modal/logs-records-main-modal/logs-records-main-modal.component';

import { GenericService } from '../../../services/generic.service';

@Component({
  selector: 'app-logs-records-confirm-modal',
  templateUrl: './logs-records-confirm-modal.component.html',
  styleUrls: ['./logs-records-confirm-modal.component.css']
})
export class LogsRecordsConfirmModalComponent implements OnInit {

  headers_name: string;

  constructor(
    public matDialogRef: MatDialogRef<LogsRecordsConfirmModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, public dialog: MatDialog, public genericService: GenericService) { 
      this.headers_name = genericService.getHeadersDisplay();
    }

  onNoClick(): void {
    this.matDialogRef.close({
      name: this.headers_name
    });
  }

  viewLogs(){
    this.dialog.closeAll();
    const dialogRef = this.dialog.open(LogsRecordsMainModalComponent, {
      height: '400px',
      width: '500px',
      data: { name: this.headers_name }
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      this.headers_name= result;
    });
  }

  ngOnInit(): void {
  }

}
