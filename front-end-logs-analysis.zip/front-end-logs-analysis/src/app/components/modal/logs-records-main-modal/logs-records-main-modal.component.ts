import { Component, OnInit, Inject, ViewChild, ElementRef} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NgxSpinnerService } from "ngx-spinner";

import { DomSanitizer } from '@angular/platform-browser';

import { LogsServiceService } from '../../../services/logs-service.service';
import { GenericService } from '../../../services/generic.service';
import { MessageService } from '../../../services/message.service';

@Component({
  selector: 'app-logs-records-main-modal',
  templateUrl: './logs-records-main-modal.component.html',
  styleUrls: ['./logs-records-main-modal.component.css']
})
export class LogsRecordsMainModalComponent implements OnInit {

  @ViewChild('iframe', {static: false}) iframe: ElementRef;
  
  headers_name: string;

  constructor(
    public dialogRef: MatDialogRef<LogsRecordsMainModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private sanitizer: DomSanitizer, 
    public  logsService: LogsServiceService, private spinner: NgxSpinnerService, public genericService: GenericService,
    public messageService: MessageService) { }

  ngOnInit(): void {  }

  onLoadIFrame(iframe){
    this.headers_name = this.genericService.getHeadersDisplay();
    const iframedoc = iframe.contentDocument || iframe.contentWindow;
    if (iframedoc){
      // Put the content in the iframe
      iframedoc.open();
      const data = this.logsService.downloadModalLogs(this.genericService.getDropDownId()).subscribe(data =>{
        iframedoc.writeln(JSON.stringify(data));
        this.spinner.hide();
      }, (err) => {
        this.messageService.error(this.genericService.handleError(err));
      });
      iframedoc.close();
    }
  }

  safeHTML(content) {
    return this.sanitizer.bypassSecurityTrustHtml(content);
  }

}
