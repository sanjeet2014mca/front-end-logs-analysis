import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogsRecordsMainModalComponent } from './logs-records-main-modal.component';

describe('LogsRecordsMainModalComponent', () => {
  let component: LogsRecordsMainModalComponent;
  let fixture: ComponentFixture<LogsRecordsMainModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogsRecordsMainModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogsRecordsMainModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
