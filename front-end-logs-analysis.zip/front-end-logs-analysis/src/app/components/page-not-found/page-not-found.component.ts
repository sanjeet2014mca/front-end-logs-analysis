import { Component, OnInit } from '@angular/core';
import { SessionStorageService, SessionStorage } from 'angular-web-storage';

import { GenericService } from '../../services/generic.service';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  @SessionStorage('userSession') userSession;

  constructor(public genericService: GenericService) {
    console.log('Page not found');
  }

  ngOnInit() {
    console.log('Is Page found ? - ' + this.genericService.ifPageFound());
  }

  takeMeHome() {
    if(this.userSession != null){
      this.genericService.navigate('homepage');
    }else{
      this.genericService.navigate('dashboard');
    }
  }

  goBack() {
    this.genericService.goBack();
  }

}
