import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes, Router, ActivatedRoute } from '@angular/router';


import { DashboardComponent } from './components/dashboard/dashboard.component';
import { RegisterComponent } from './components/login-register/register/register.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { UploadComponent } from './components/upload/upload.component';
import { DownloadComponent } from './components/download/download.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { LogsRecordsComponent } from './components/logs-records/logs-records.component';

import { RouteguardService as routeSessionValidator} from './services/routeguard.service';
import { GenericService } from './services/generic.service';
import { LoginComponent } from './components/login-register/login/login.component';

const routes: Routes = [

  // { path: '', component: DashboardComponent, data: { title: 'Dashboard here' } },
  // {path: 'dashboard', component: DashboardComponent, data: { title: 'Dashboard here' } },
  {path: '', component: LoginComponent, data: { title: 'Login here' }  },
  {path: 'login', component: LoginComponent, data: { title: 'Login here' }  },
  {path: 'logout', component: LoginComponent},
  {path: 'register', component: RegisterComponent},
  // {path: 'homepage', component: HomepageComponent, canActivate: [routeSessionValidator] },
  // {path: 'upload', component: UploadComponent, canActivate: [routeSessionValidator] },
  // {path: 'download', component: DownloadComponent, canActivate: [routeSessionValidator] },
  {path: 'logs', component: LogsRecordsComponent, canActivate: [routeSessionValidator] },
  {path: '**', component: PageNotFoundComponent}, //always last

];

@NgModule({
  imports: [RouterModule.forRoot(routes,
    { enableTracing: false ,onSameUrlNavigation: 'reload'} )
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { 
  constructor(public genericService:GenericService, private route: ActivatedRoute, 
    private router: Router) {
      console.log(this.route.snapshot.params.id);
}

}
